To run this project it is the same as for Peerster, except that there is one
additional flag "genesis" that can take the values true or false.

By default it is false because nodes want to join an already existing network.
If set to true, the gossiper will start the blockchain.